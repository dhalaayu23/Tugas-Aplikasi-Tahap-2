/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kulkas.model;


import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 *
 * @author didik
 */
public class KulkasProperty {
   private String kd_kulkas;
    private String nama;
    private String tglProduksi;
    private String merk;
    private String ukuran;
    private String harga;
    
    

    public KulkasProperty(String npm, String nama, String tanggalLahir, String gender, String prodi) {
        this.kd_kulkas = new SimpleStringProperty(kd_kulkas);
        this.nama = new SimpleStringProperty(nama);
        this.tglProduksi = new SimpleStringProperty(tglProduksi);
        this.merk = new SimpleStringProperty(merk);
        this.ukuran = new SimpleStringProperty(ukuran);
         this.harga = new SimpleStringProperty(harga);
    }
    public KulkasProperty(Kulkas kls){
        this.kd_kulkas = new SimpleStringProperty(kls.getkd_kulkas());
        this.nama = new SimpleStringProperty(kls.getNama());
        this.tglproduksi = new SimpleStringProperty(kls.gettglproduksi());
        this.merk = new SimpleStringProperty(mhs.getmerk());
        this.ukuran = new SimpleStringProperty(mhs.getukuran());
         this.harga = new SimpleStringProperty(kls.getharga());
    }
    public StringProperty getd_kulkasProperty() {
        return kd_kulkas;
    }

    public void setProdi(String kd_kulkas) {
        this.kd_kulkas = new SimpleStringProperty(kd_kulkas);
    }

    public StringProperty getNpmProperty() {
        return ;
    }

    public void setmerk(String merk) {
        this.npm = new SimpleStringProperty(npm);
    }

    public StringProperty getNamaProperty() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = new SimpleStringProperty(nama);
    }

    public StringProperty getTglProduksiProperty() {
        return tglproduksi;
    }

    public void setTglproduksi(String tglproduksi) {
        this.tglproduksi = new SimpleStringProperty(tglproduksi);
    }

    public StringProperty getmerkProperty() {
        return merk;
    }

    public void setukuran(String ukuran) {
        this.ukuran = new SimpleStringProperty(ukuran);
    }

    public String getkd_kulkas() {
        return kd_kulkas.get();
    }

    public String getNama() {
        return nama.get();
    }

    public String getTglproduksi() {
        return tanggalLahir.get();
    }

    public String getTglproduksi() {
        return tglproduksi.get();
    }

    public String getharga() {
        return harga.get();
    }
    
}
