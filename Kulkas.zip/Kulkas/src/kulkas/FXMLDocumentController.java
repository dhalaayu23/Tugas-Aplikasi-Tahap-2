/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kulkas;

import java.net.URL;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import kulkas.db.DBHandler;
import kulkas.model.kulkas;

/**
 *
 * @author ASUS
 */
public class FXMLDocumentController implements Initializable {
   @FXML
    private Button btnSave;

    @FXML
    private ComboBox<?> cbUkuran;

    @FXML
    private DatePicker dpTanggalProduksi;

    @FXML
    private ToggleGroup merk;

    @FXML
    private RadioButton rdLG;

    @FXML
    private RadioButton rdPanasonic;
    
    @FXML
    private RadioButton rdSharp;

    @FXML
    private TextField kd_kulkas;

    @FXML
    private TextField tfNama;
    
    @FXML
    private TextField tfHarga;
    
    @FXML
    private void handleButtonAction(ActionEvent event) {
        System.out.println(kd_kulkas.getText());
        System.out.println(tfNama.getText());
        System.out.println(dpTanggalProduksi.getValue().toString());
        String merk ="";
        if(rdLG.isSelected())
            merk = rdLG.getText();
        if(rdSharp.isSelected())
            merk = rdSharp.getText();
        if(rdPanasonic.isSelected())
            merk = rdPanasonic.getText();
        System.out.println(merk);
        System.out.println(cbUkuran.getValue().toString());
        System.out.println(tfHarga.getText());
        
        Kulkas t = new Kulkas(kd_kulkas.getText(),tfNama.getText(),dpTanggalProduksi.getValue().toString(),
        merk,cbUkuran.getValue().toString(), tfHarga.getText());
        
        DBHandler dh = new DBHandler("MYSQL");
        dh.addKulkas(t);
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        ArrayList <String> list = new ArrayList<String>();
        list.add("1 pintu");
        list.add("2 pintu");
     
        
        ObservableList items = FXCollections.observableArrayList(list);
        
        cbUkuran.setItems(items);
    }    
    
}
